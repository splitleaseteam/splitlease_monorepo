/**
 * PATTERN 3: PRICE ANCHORING - HOOKS INDEX
 * Central export for all custom hooks
 */

export * from './usePriceAnchor';
export * from './useSavingsCalculations';
