// =====================================================
// PRICE ANCHORING SERVICE
// =====================================================
// Pattern 3: Price Anchoring - Core Business Logic
// Provides utilities for price calculations and tier management
// =====================================================

import { SupabaseClient } from '@supabase/supabase-js';

// =====================================================
// TYPES
// =====================================================

export interface PriceTier {
  tier_id: string;
  tier_name: string;
  multiplier: number;
  calculated_price: number;
  display_order: number;
  badge_text: string | null;
  description: string;
  acceptance_rate: number;
  avg_response_time_hours: number;
  is_recommended: boolean;
  features: TierFeature[];
  savings_amount: number;
  savings_percentage: number;
}

export interface TierFeature {
  text: string;
  icon: string;
  order: number;
}

export interface PriceAnchor {
  price: number;
  type: 'buyout' | 'market_rate' | 'recommended' | 'custom';
  description: string;
}

export interface AnchorContext {
  anchor: PriceAnchor;
  tiers: PriceTier[];
  recommended_tier: RecommendedTier;
  base_price: number;
}

export interface RecommendedTier {
  tier_id: string;
  tier_name: string;
  multiplier: number;
  reason: string;
}

export interface SavingsCalculation {
  savings_amount: number;
  savings_percentage: number;
  formatted_amount: string;
  formatted_percentage: string;
  formatted_combined: string;
  is_saving: boolean;
  saving_tier: 'none' | 'modest' | 'good' | 'massive';
  display_message: string;
}

export type UserArchetype = 'big_spender' | 'high_flexibility' | 'average_user';
export type Urgency = 'low' | 'medium' | 'high';

// =====================================================
// PRICE ANCHORING SERVICE CLASS
// =====================================================

export class PriceAnchoringService {
  private supabase: SupabaseClient;

  constructor(supabase: SupabaseClient) {
    this.supabase = supabase;
  }

  // =====================================================
  // GET PRICING TIERS
  // =====================================================

  async getPricingTiers(
    basePrice: number,
    anchorPrice?: number,
    anchorType: PriceAnchor['type'] = 'buyout'
  ): Promise<{ tiers: PriceTier[]; anchor: PriceAnchor }> {
    const effectiveAnchorPrice = anchorPrice || basePrice;

    const { data, error } = await this.supabase.rpc('get_all_tier_prices', {
      p_base_price: basePrice,
      p_anchor_price: effectiveAnchorPrice,
    });

    if (error) {
      throw new Error(`Failed to fetch pricing tiers: ${error.message}`);
    }

    if (!data || data.length === 0) {
      throw new Error('No active pricing tiers found');
    }

    return {
      tiers: data,
      anchor: {
        price: effectiveAnchorPrice,
        type: anchorType,
        description: this.getAnchorDescription(anchorType),
      },
    };
  }

  // =====================================================
  // GET RECOMMENDED TIER
  // =====================================================

  async getRecommendedTier(
    userArchetype: UserArchetype = 'average_user',
    urgency: Urgency = 'medium'
  ): Promise<RecommendedTier> {
    const { data, error } = await this.supabase.rpc('get_recommended_tier', {
      p_user_archetype: userArchetype,
      p_urgency: urgency,
    });

    if (error) {
      console.error('Error fetching recommended tier:', error);
      // Return default recommendation
      return {
        tier_id: 'recommended',
        tier_name: 'Recommended',
        multiplier: 1.0,
        reason: 'Most popular choice among users',
      };
    }

    return data?.[0] || {
      tier_id: 'recommended',
      tier_name: 'Recommended',
      multiplier: 1.0,
      reason: 'Default recommendation',
    };
  }

  // =====================================================
  // GET COMPLETE ANCHOR CONTEXT
  // =====================================================

  async getAnchorContext(
    basePrice: number,
    anchorPrice?: number,
    anchorType: PriceAnchor['type'] = 'buyout',
    userArchetype: UserArchetype = 'average_user',
    urgency: Urgency = 'medium'
  ): Promise<AnchorContext> {
    const [{ tiers, anchor }, recommendedTier] = await Promise.all([
      this.getPricingTiers(basePrice, anchorPrice, anchorType),
      this.getRecommendedTier(userArchetype, urgency),
    ]);

    return {
      anchor,
      tiers,
      recommended_tier: recommendedTier,
      base_price: basePrice,
    };
  }

  // =====================================================
  // CALCULATE TIER PRICE
  // =====================================================

  async calculateTierPrice(
    basePrice: number,
    tierId: string
  ): Promise<number> {
    const { data, error } = await this.supabase.rpc('calculate_tier_price', {
      p_base_price: basePrice,
      p_tier_id: tierId,
    });

    if (error) {
      throw new Error(`Failed to calculate tier price: ${error.message}`);
    }

    return data;
  }

  // =====================================================
  // CALCULATE SAVINGS
  // =====================================================

  async calculateSavings(
    offerPrice: number,
    anchorPrice: number
  ): Promise<{ amount: number; percentage: number }> {
    const { data, error } = await this.supabase.rpc('calculate_savings', {
      p_offer_price: offerPrice,
      p_anchor_price: anchorPrice,
    });

    if (error) {
      throw new Error(`Failed to calculate savings: ${error.message}`);
    }

    const result = data?.[0] || { savings_amount: 0, savings_percentage: 0 };

    return {
      amount: result.savings_amount,
      percentage: result.savings_percentage,
    };
  }

  // =====================================================
  // CALCULATE SAVINGS WITH FORMATTING
  // =====================================================

  calculateSavingsLocal(
    offerPrice: number,
    anchorPrice: number,
    currency: string = 'USD'
  ): SavingsCalculation {
    const savingsAmount = anchorPrice - offerPrice;
    const savingsPercentage = anchorPrice > 0
      ? (savingsAmount / anchorPrice) * 100
      : 0;

    const savingsTier = this.getSavingsTier(savingsPercentage);
    const formattedAmount = this.formatCurrency(savingsAmount, currency);
    const formattedPercentage = this.formatPercentage(savingsPercentage);

    return {
      savings_amount: Math.round(savingsAmount * 100) / 100,
      savings_percentage: Math.round(savingsPercentage * 100) / 100,
      formatted_amount: formattedAmount,
      formatted_percentage: formattedPercentage,
      formatted_combined: `${formattedAmount} (${formattedPercentage} off)`,
      is_saving: savingsAmount > 0,
      saving_tier: savingsTier,
      display_message: this.getDisplayMessage(savingsAmount, savingsPercentage, savingsTier),
    };
  }

  // =====================================================
  // TRACK TIER SELECTION
  // =====================================================

  async trackTierSelection(params: {
    bookingId: string;
    userId: string;
    sessionId: string;
    tierId: string;
    basePrice: number;
    anchorPrice: number;
    anchorType: PriceAnchor['type'];
    platformFee?: number;
    metadata?: Record<string, any>;
  }): Promise<string> {
    // Get tier information
    const { data: tierData, error: tierError } = await this.supabase
      .from('pricing_tiers')
      .select('tier_id, tier_name, multiplier')
      .eq('tier_id', params.tierId)
      .eq('is_active', true)
      .single();

    if (tierError || !tierData) {
      throw new Error(`Invalid or inactive tier: ${params.tierId}`);
    }

    // Calculate prices
    const finalPrice = Math.round(params.basePrice * tierData.multiplier * 100) / 100;
    const platformFee = params.platformFee || 0;
    const totalCost = finalPrice + platformFee;

    // Calculate savings
    const savings = await this.calculateSavings(totalCost, params.anchorPrice);

    // Create tier_selections record
    const { data: selectionData, error: selectionError } = await this.supabase
      .from('tier_selections')
      .insert({
        booking_id: params.bookingId,
        user_id: params.userId,
        tier_id: params.tierId,
        tier_name: tierData.tier_name,
        base_price: params.basePrice,
        multiplier: tierData.multiplier,
        final_price: finalPrice,
        platform_fee: platformFee,
        total_cost: totalCost,
        anchor_price: params.anchorPrice,
        savings_vs_anchor: savings.amount,
        savings_percentage: savings.percentage,
        transaction_status: 'pending',
        metadata: {
          ...params.metadata,
          anchor_type: params.anchorType,
          selected_at: new Date().toISOString(),
        },
      })
      .select('id')
      .single();

    if (selectionError) {
      throw new Error(`Failed to create tier selection: ${selectionError.message}`);
    }

    // Track analytics event
    try {
      await this.trackAnalyticsEvent({
        userId: params.userId,
        sessionId: params.sessionId,
        eventType: 'tier_selected',
        basePrice: params.basePrice,
        anchorPrice: params.anchorPrice,
        anchorType: params.anchorType,
        selectedTierId: params.tierId,
        selectedPrice: totalCost,
        bookingId: params.bookingId,
        metadata: {
          selection_id: selectionData.id,
          ...params.metadata,
        },
      });
    } catch (error) {
      console.error('Failed to track analytics event:', error);
      // Don't fail the request
    }

    return selectionData.id;
  }

  // =====================================================
  // TRACK ANALYTICS EVENT
  // =====================================================

  async trackAnalyticsEvent(params: {
    userId?: string;
    sessionId: string;
    eventType: 'tiers_viewed' | 'tier_selected' | 'tier_changed' | 'custom_price_entered' | 'transaction_completed' | 'transaction_abandoned';
    basePrice: number;
    anchorPrice: number;
    anchorType: PriceAnchor['type'];
    selectedTierId?: string;
    selectedPrice?: number;
    bookingId?: string;
    metadata?: Record<string, any>;
  }): Promise<string> {
    // Get tiers shown
    const { tiers } = await this.getPricingTiers(params.basePrice, params.anchorPrice);

    const { data, error } = await this.supabase.rpc('track_tier_selection_event', {
      p_user_id: params.userId || null,
      p_session_id: params.sessionId,
      p_event_type: params.eventType,
      p_base_price: params.basePrice,
      p_anchor_price: params.anchorPrice,
      p_anchor_type: params.anchorType,
      p_tiers_shown: JSON.stringify(tiers),
      p_selected_tier_id: params.selectedTierId || null,
      p_selected_price: params.selectedPrice || null,
      p_booking_id: params.bookingId || null,
      p_metadata: JSON.stringify(params.metadata || {}),
    });

    if (error) {
      throw new Error(`Failed to track analytics event: ${error.message}`);
    }

    return data;
  }

  // =====================================================
  // GET TIER ANALYTICS
  // =====================================================

  async getTierAnalytics(
    startDate?: Date,
    endDate?: Date
  ): Promise<Array<{
    tier_id: string;
    tier_name: string;
    total_views: number;
    total_selections: number;
    selection_rate: number;
    avg_savings_amount: number;
    avg_savings_percentage: number;
    total_revenue: number;
  }>> {
    const start = startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate || new Date();

    const { data, error } = await this.supabase.rpc('get_tier_analytics', {
      p_start_date: start.toISOString(),
      p_end_date: end.toISOString(),
    });

    if (error) {
      throw new Error(`Failed to fetch tier analytics: ${error.message}`);
    }

    return data || [];
  }

  // =====================================================
  // HELPER: GET ANCHOR DESCRIPTION
  // =====================================================

  private getAnchorDescription(anchorType: PriceAnchor['type']): string {
    const descriptions: Record<string, string> = {
      buyout: 'Exclusive buyout rate - your reference price',
      market_rate: 'Current market rate for similar options',
      recommended: 'Recommended fair market price',
      custom: 'Your specified reference price',
    };

    return descriptions[anchorType] || 'Reference price';
  }

  // =====================================================
  // HELPER: GET SAVINGS TIER
  // =====================================================

  private getSavingsTier(savingsPercentage: number): 'none' | 'modest' | 'good' | 'massive' {
    if (savingsPercentage < 0) return 'none';
    if (savingsPercentage < 20) return 'modest';
    if (savingsPercentage < 50) return 'good';
    return 'massive';
  }

  // =====================================================
  // HELPER: FORMAT CURRENCY
  // =====================================================

  private formatCurrency(amount: number, currency: string): string {
    const isNegative = amount < 0;
    const absAmount = Math.abs(amount);

    const formatted = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(absAmount);

    return isNegative ? `-${formatted}` : formatted;
  }

  // =====================================================
  // HELPER: FORMAT PERCENTAGE
  // =====================================================

  private formatPercentage(percentage: number): string {
    return `${Math.round(percentage)}%`;
  }

  // =====================================================
  // HELPER: GET DISPLAY MESSAGE
  // =====================================================

  private getDisplayMessage(
    savingsAmount: number,
    savingsPercentage: number,
    savingsTier: string
  ): string {
    if (savingsAmount <= 0) {
      return 'No savings - this costs more than the reference price';
    }

    const percentStr = this.formatPercentage(savingsPercentage);
    const amountStr = this.formatCurrency(savingsAmount, 'USD');

    switch (savingsTier) {
      case 'massive':
        if (savingsPercentage >= 99) {
          return `Save ${amountStr} - Basically free!`;
        }
        return `Save ${amountStr} (${percentStr} off!) - Incredible value`;

      case 'good':
        return `Save ${amountStr} (${percentStr} off) - Great deal`;

      case 'modest':
        return `Save ${amountStr} (${percentStr} off)`;

      default:
        return 'Reference price comparison';
    }
  }
}

// =====================================================
// FACTORY FUNCTION
// =====================================================

export function createPriceAnchoringService(
  supabase: SupabaseClient
): PriceAnchoringService {
  return new PriceAnchoringService(supabase);
}

// =====================================================
// CONSTANTS
// =====================================================

export const PRICE_TIER_MULTIPLIERS = {
  BUDGET: 0.90,
  RECOMMENDED: 1.00,
  PREMIUM: 1.15,
} as const;

export const DEFAULT_TIER_IDS = {
  BUDGET: 'budget',
  RECOMMENDED: 'recommended',
  PREMIUM: 'premium',
} as const;

export const SAVINGS_THRESHOLDS = {
  MODEST: 20,
  GOOD: 50,
  MASSIVE: 80,
} as const;
