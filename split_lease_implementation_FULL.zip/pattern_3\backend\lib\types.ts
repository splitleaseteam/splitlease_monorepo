// =====================================================
// TYPE DEFINITIONS
// =====================================================
// Shared types for Pattern 3: Price Anchoring
// =====================================================

// =====================================================
// PRICING TIERS
// =====================================================

export interface PriceTier {
  tier_id: string;
  tier_name: string;
  multiplier: number;
  calculated_price: number;
  display_order: number;
  badge_text: string | null;
  description: string;
  acceptance_rate: number;
  avg_response_time_hours: number;
  is_recommended: boolean;
  features: TierFeature[];
  savings_amount: number;
  savings_percentage: number;
}

export interface TierFeature {
  text: string;
  icon: string;
  order: number;
}

export interface PriceTierConfig {
  tier_id: string;
  tier_name: string;
  multiplier: number;
  display_order: number;
  badge_text: string | null;
  description: string;
  acceptance_rate: number;
  avg_response_time_hours: number;
  is_recommended: boolean;
  is_active: boolean;
  metadata: Record<string, any>;
}

// =====================================================
// ANCHORING
// =====================================================

export interface PriceAnchor {
  price: number;
  type: AnchorType;
  description: string;
}

export type AnchorType = 'buyout' | 'market_rate' | 'recommended' | 'custom';

export interface AnchorContext {
  anchor: PriceAnchor;
  tiers: PriceTier[];
  recommended_tier: RecommendedTier;
  base_price: number;
}

export interface RecommendedTier {
  tier_id: string;
  tier_name: string;
  multiplier: number;
  reason: string;
}

// =====================================================
// SAVINGS
// =====================================================

export interface SavingsCalculation {
  savings_amount: number;
  savings_percentage: number;
  formatted_amount: string;
  formatted_percentage: string;
  formatted_combined: string;
  is_saving: boolean;
  saving_tier: SavingsTier;
  display_message: string;
}

export type SavingsTier = 'none' | 'modest' | 'good' | 'massive';

export interface SavingsComparison {
  offer_price: number;
  anchor_price: number;
  savings_amount: number;
  savings_percentage: number;
  is_better_deal: boolean;
}

// =====================================================
// USER CONTEXT
// =====================================================

export type UserArchetype = 'big_spender' | 'high_flexibility' | 'average_user';

export type Urgency = 'low' | 'medium' | 'high';

export interface UserContext {
  user_id?: string;
  user_archetype: UserArchetype;
  urgency: Urgency;
  budget_preference?: 'tight' | 'flexible' | 'unlimited';
  history?: UserHistory;
}

export interface UserHistory {
  has_accepted_premium: boolean;
  has_accepted_budget: boolean;
  avg_accepted_tier_multiplier: number;
  total_transactions: number;
}

// =====================================================
// TIER SELECTION
// =====================================================

export interface TierSelection {
  id: string;
  booking_id: string;
  user_id: string;
  tier_id: string;
  tier_name: string;
  base_price: number;
  multiplier: number;
  final_price: number;
  platform_fee: number;
  total_cost: number;
  anchor_price: number;
  savings_vs_anchor: number;
  savings_percentage: number;
  transaction_status: TransactionStatus;
  completed_at: string | null;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export type TransactionStatus = 'pending' | 'completed' | 'cancelled' | 'expired';

export interface TierSelectionRequest {
  booking_id: string;
  user_id: string;
  session_id: string;
  tier_id: string;
  base_price: number;
  anchor_price: number;
  anchor_type: AnchorType;
  platform_fee?: number;
  transaction_type?: string;
  metadata?: Record<string, any>;
}

// =====================================================
// ANALYTICS
// =====================================================

export interface PriceAnchoringEvent {
  id: string;
  user_id: string | null;
  session_id: string;
  event_type: AnalyticsEventType;
  base_price: number;
  anchor_price: number;
  anchor_type: AnchorType;
  tiers_shown: PriceTier[];
  selected_tier_id: string | null;
  selected_price: number | null;
  savings_amount: number | null;
  savings_percentage: number | null;
  booking_id: string | null;
  transaction_type: string | null;
  user_archetype: UserArchetype | null;
  metadata: Record<string, any>;
  created_at: string;
}

export type AnalyticsEventType =
  | 'tiers_viewed'
  | 'tier_selected'
  | 'tier_changed'
  | 'custom_price_entered'
  | 'transaction_completed'
  | 'transaction_abandoned';

export interface TierAnalytics {
  tier_id: string;
  tier_name: string;
  total_views: number;
  total_selections: number;
  selection_rate: number;
  avg_savings_amount: number;
  avg_savings_percentage: number;
  total_revenue: number;
}

export interface AnalyticsTrackingParams {
  userId?: string;
  sessionId: string;
  eventType: AnalyticsEventType;
  basePrice: number;
  anchorPrice: number;
  anchorType: AnchorType;
  selectedTierId?: string;
  selectedPrice?: number;
  bookingId?: string;
  metadata?: Record<string, any>;
}

// =====================================================
// A/B TESTING
// =====================================================

export interface ABTestVariant {
  id: string;
  test_name: string;
  variant_name: string;
  tier_multipliers: Record<string, number>;
  display_order: string;
  savings_format: SavingsFormat;
  traffic_percentage: number;
  is_active: boolean;
  impressions: number;
  selections: number;
  conversions: number;
  description: string | null;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export type SavingsFormat = 'absolute' | 'percentage' | 'both';

export interface ABTestResults {
  variant_name: string;
  impressions: number;
  selections: number;
  conversions: number;
  ctr: number;
  conversion_rate: number;
}

// =====================================================
// API REQUESTS/RESPONSES
// =====================================================

export interface GetPricingTiersRequest {
  base_price: number;
  anchor_price?: number;
  anchor_type?: AnchorType;
  user_archetype?: UserArchetype;
  urgency?: Urgency;
  booking_id?: string;
  session_id: string;
  user_id?: string;
}

export interface GetPricingTiersResponse {
  success: boolean;
  data?: {
    tiers: PriceTier[];
    anchor: PriceAnchor;
    recommended_tier: RecommendedTier;
    metadata: {
      base_price: number;
      total_tiers: number;
      generated_at: string;
    };
  };
  error?: ApiError;
}

export interface TrackTierSelectionRequest {
  booking_id: string;
  user_id: string;
  session_id: string;
  tier_id: string;
  base_price: number;
  anchor_price: number;
  anchor_type: AnchorType;
  platform_fee?: number;
  transaction_type?: string;
  metadata?: Record<string, any>;
}

export interface TrackTierSelectionResponse {
  success: boolean;
  data?: {
    selection_id: string;
    tier_id: string;
    tier_name: string;
    final_price: number;
    total_cost: number;
    savings_amount: number;
    savings_percentage: number;
    transaction_status: TransactionStatus;
    created_at: string;
  };
  error?: ApiError;
}

export interface CalculateSavingsRequest {
  offer_price: number;
  anchor_price: number;
  format?: SavingsFormat;
  currency?: string;
}

export interface CalculateSavingsResponse {
  success: boolean;
  data?: SavingsCalculation;
  error?: ApiError;
}

export interface ApiError {
  message: string;
  code: string;
  details?: any;
}

// =====================================================
// DATABASE MODELS
// =====================================================

export interface PricingTierRow {
  id: string;
  tier_name: string;
  tier_id: string;
  multiplier: number;
  display_order: number;
  badge_text: string | null;
  description: string;
  acceptance_rate: number;
  avg_response_time_hours: number;
  is_recommended: boolean;
  is_active: boolean;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface TierFeatureRow {
  id: string;
  tier_id: string;
  feature_text: string;
  display_order: number;
  icon: string;
  is_active: boolean;
  created_at: string;
}

export interface PriceAnchoringEventRow {
  id: string;
  user_id: string | null;
  session_id: string;
  event_type: AnalyticsEventType;
  base_price: number;
  anchor_price: number;
  anchor_type: AnchorType;
  tiers_shown: any;
  selected_tier_id: string | null;
  selected_price: number | null;
  savings_amount: number | null;
  savings_percentage: number | null;
  booking_id: string | null;
  transaction_type: string | null;
  user_archetype: UserArchetype | null;
  metadata: Record<string, any>;
  created_at: string;
}

export interface TierSelectionRow {
  id: string;
  booking_id: string;
  user_id: string;
  tier_id: string;
  tier_name: string;
  base_price: number;
  multiplier: number;
  final_price: number;
  platform_fee: number;
  total_cost: number;
  anchor_price: number;
  savings_vs_anchor: number;
  savings_percentage: number;
  transaction_status: TransactionStatus;
  completed_at: string | null;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
}

// =====================================================
// CONSTANTS
// =====================================================

export const TIER_IDS = {
  BUDGET: 'budget',
  RECOMMENDED: 'recommended',
  PREMIUM: 'premium',
  CUSTOM: 'custom',
} as const;

export const TIER_MULTIPLIERS = {
  BUDGET: 0.90,
  RECOMMENDED: 1.00,
  PREMIUM: 1.15,
} as const;

export const SAVINGS_THRESHOLDS = {
  MODEST: 20,
  GOOD: 50,
  MASSIVE: 80,
} as const;

export const ANCHOR_TYPES = {
  BUYOUT: 'buyout',
  MARKET_RATE: 'market_rate',
  RECOMMENDED: 'recommended',
  CUSTOM: 'custom',
} as const;

export const EVENT_TYPES = {
  TIERS_VIEWED: 'tiers_viewed',
  TIER_SELECTED: 'tier_selected',
  TIER_CHANGED: 'tier_changed',
  CUSTOM_PRICE_ENTERED: 'custom_price_entered',
  TRANSACTION_COMPLETED: 'transaction_completed',
  TRANSACTION_ABANDONED: 'transaction_abandoned',
} as const;

export const TRANSACTION_STATUSES = {
  PENDING: 'pending',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
  EXPIRED: 'expired',
} as const;
